﻿namespace Cartagena_1_3
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.label36 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtExibetabuleiro = new System.Windows.Forms.TextBox();
            this.txtPosicao = new System.Windows.Forms.TextBox();
            this.cboSimbolo = new MetroFramework.Controls.MetroComboBox();
            this.cboPartida = new MetroFramework.Controls.MetroComboBox();
            this.lblSimbolo = new MetroFramework.Controls.MetroLabel();
            this.lblPosicao = new MetroFramework.Controls.MetroLabel();
            this.lblCorJogador = new MetroFramework.Controls.MetroLabel();
            this.lblSenhaJogador = new MetroFramework.Controls.MetroLabel();
            this.lblIdJogador = new MetroFramework.Controls.MetroLabel();
            this.lblNomeJogador = new MetroFramework.Controls.MetroLabel();
            this.lblIdPartida = new MetroFramework.Controls.MetroLabel();
            this.lblSenhaPartida = new MetroFramework.Controls.MetroLabel();
            this.lblNomePartida = new MetroFramework.Controls.MetroLabel();
            this.txtExibeVez = new System.Windows.Forms.TextBox();
            this.txtExibeMao = new System.Windows.Forms.TextBox();
            this.txtCorJogador = new System.Windows.Forms.TextBox();
            this.txtSenhaJogador = new System.Windows.Forms.TextBox();
            this.txtIdJogador = new System.Windows.Forms.TextBox();
            this.txtNomeJogador = new System.Windows.Forms.TextBox();
            this.txtExibeJogadores = new System.Windows.Forms.TextBox();
            this.txtIdPartida = new System.Windows.Forms.TextBox();
            this.txtExibeHistorico = new System.Windows.Forms.TextBox();
            this.txtSenhaPartida = new System.Windows.Forms.TextBox();
            this.txtNomePartida = new System.Windows.Forms.TextBox();
            this.txtExibePartida = new System.Windows.Forms.TextBox();
            this.btnExibirTabuleiro = new MetroFramework.Controls.MetroButton();
            this.btnVerificarVez = new MetroFramework.Controls.MetroButton();
            this.btnExibirMao = new MetroFramework.Controls.MetroButton();
            this.btnPularJogada = new MetroFramework.Controls.MetroButton();
            this.btnJogarTras = new MetroFramework.Controls.MetroButton();
            this.btnJogarFrente = new MetroFramework.Controls.MetroButton();
            this.btnIniciarPartida = new MetroFramework.Controls.MetroButton();
            this.btnEntrarPartida = new MetroFramework.Controls.MetroButton();
            this.btnListarJogadores = new MetroFramework.Controls.MetroButton();
            this.btnExibirHistorico = new MetroFramework.Controls.MetroButton();
            this.btnCriarPartida = new MetroFramework.Controls.MetroButton();
            this.btmListarPartida = new MetroFramework.Controls.MetroButton();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.BackColor = System.Drawing.Color.AliceBlue;
            this.metroPanel1.Controls.Add(this.label36);
            this.metroPanel1.Controls.Add(this.label35);
            this.metroPanel1.Controls.Add(this.label34);
            this.metroPanel1.Controls.Add(this.label33);
            this.metroPanel1.Controls.Add(this.label32);
            this.metroPanel1.Controls.Add(this.label31);
            this.metroPanel1.Controls.Add(this.label30);
            this.metroPanel1.Controls.Add(this.label29);
            this.metroPanel1.Controls.Add(this.label28);
            this.metroPanel1.Controls.Add(this.label27);
            this.metroPanel1.Controls.Add(this.label26);
            this.metroPanel1.Controls.Add(this.label25);
            this.metroPanel1.Controls.Add(this.label24);
            this.metroPanel1.Controls.Add(this.label23);
            this.metroPanel1.Controls.Add(this.label22);
            this.metroPanel1.Controls.Add(this.label21);
            this.metroPanel1.Controls.Add(this.label20);
            this.metroPanel1.Controls.Add(this.label19);
            this.metroPanel1.Controls.Add(this.label18);
            this.metroPanel1.Controls.Add(this.label17);
            this.metroPanel1.Controls.Add(this.label16);
            this.metroPanel1.Controls.Add(this.label15);
            this.metroPanel1.Controls.Add(this.label14);
            this.metroPanel1.Controls.Add(this.label13);
            this.metroPanel1.Controls.Add(this.label12);
            this.metroPanel1.Controls.Add(this.label11);
            this.metroPanel1.Controls.Add(this.label10);
            this.metroPanel1.Controls.Add(this.label9);
            this.metroPanel1.Controls.Add(this.label8);
            this.metroPanel1.Controls.Add(this.label7);
            this.metroPanel1.Controls.Add(this.label6);
            this.metroPanel1.Controls.Add(this.label5);
            this.metroPanel1.Controls.Add(this.label4);
            this.metroPanel1.Controls.Add(this.label3);
            this.metroPanel1.Controls.Add(this.label2);
            this.metroPanel1.Controls.Add(this.label1);
            this.metroPanel1.Controls.Add(this.pictureBox1);
            this.metroPanel1.Controls.Add(this.txtExibetabuleiro);
            this.metroPanel1.Controls.Add(this.txtPosicao);
            this.metroPanel1.Controls.Add(this.cboSimbolo);
            this.metroPanel1.Controls.Add(this.cboPartida);
            this.metroPanel1.Controls.Add(this.lblSimbolo);
            this.metroPanel1.Controls.Add(this.lblPosicao);
            this.metroPanel1.Controls.Add(this.lblCorJogador);
            this.metroPanel1.Controls.Add(this.lblSenhaJogador);
            this.metroPanel1.Controls.Add(this.lblIdJogador);
            this.metroPanel1.Controls.Add(this.lblNomeJogador);
            this.metroPanel1.Controls.Add(this.lblIdPartida);
            this.metroPanel1.Controls.Add(this.lblSenhaPartida);
            this.metroPanel1.Controls.Add(this.lblNomePartida);
            this.metroPanel1.Controls.Add(this.txtExibeVez);
            this.metroPanel1.Controls.Add(this.txtExibeMao);
            this.metroPanel1.Controls.Add(this.txtCorJogador);
            this.metroPanel1.Controls.Add(this.txtSenhaJogador);
            this.metroPanel1.Controls.Add(this.txtIdJogador);
            this.metroPanel1.Controls.Add(this.txtNomeJogador);
            this.metroPanel1.Controls.Add(this.txtExibeJogadores);
            this.metroPanel1.Controls.Add(this.txtIdPartida);
            this.metroPanel1.Controls.Add(this.txtExibeHistorico);
            this.metroPanel1.Controls.Add(this.txtSenhaPartida);
            this.metroPanel1.Controls.Add(this.txtNomePartida);
            this.metroPanel1.Controls.Add(this.txtExibePartida);
            this.metroPanel1.Controls.Add(this.btnExibirTabuleiro);
            this.metroPanel1.Controls.Add(this.btnVerificarVez);
            this.metroPanel1.Controls.Add(this.btnExibirMao);
            this.metroPanel1.Controls.Add(this.btnPularJogada);
            this.metroPanel1.Controls.Add(this.btnJogarTras);
            this.metroPanel1.Controls.Add(this.btnJogarFrente);
            this.metroPanel1.Controls.Add(this.btnIniciarPartida);
            this.metroPanel1.Controls.Add(this.btnEntrarPartida);
            this.metroPanel1.Controls.Add(this.btnListarJogadores);
            this.metroPanel1.Controls.Add(this.btnExibirHistorico);
            this.metroPanel1.Controls.Add(this.btnCriarPartida);
            this.metroPanel1.Controls.Add(this.btmListarPartida);
            this.metroPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(0, 0);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(872, 676);
            this.metroPanel1.TabIndex = 0;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // label36
            // 
            this.label36.ImageList = this.imageList1;
            this.label36.Location = new System.Drawing.Point(613, 497);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(55, 28);
            this.label36.TabIndex = 81;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "Chave.png");
            this.imageList1.Images.SetKeyName(1, "Esqueleto.png");
            this.imageList1.Images.SetKeyName(2, "Faca.png");
            this.imageList1.Images.SetKeyName(3, "Garrafa.png");
            this.imageList1.Images.SetKeyName(4, "Pistola.png");
            this.imageList1.Images.SetKeyName(5, "Triconio.png");
            // 
            // label35
            // 
            this.label35.ImageList = this.imageList1;
            this.label35.Location = new System.Drawing.Point(674, 497);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(55, 28);
            this.label35.TabIndex = 80;
            this.label35.Click += new System.EventHandler(this.label35_Click);
            // 
            // label34
            // 
            this.label34.ImageList = this.imageList1;
            this.label34.Location = new System.Drawing.Point(735, 497);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(55, 28);
            this.label34.TabIndex = 79;
            this.label34.Click += new System.EventHandler(this.label34_Click);
            // 
            // label33
            // 
            this.label33.ImageList = this.imageList1;
            this.label33.Location = new System.Drawing.Point(796, 497);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(55, 28);
            this.label33.TabIndex = 78;
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // label32
            // 
            this.label32.ImageList = this.imageList1;
            this.label32.Location = new System.Drawing.Point(796, 528);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(55, 28);
            this.label32.TabIndex = 77;
            this.label32.Click += new System.EventHandler(this.label32_Click);
            // 
            // label31
            // 
            this.label31.ImageList = this.imageList1;
            this.label31.Location = new System.Drawing.Point(735, 528);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(55, 28);
            this.label31.TabIndex = 76;
            this.label31.Click += new System.EventHandler(this.label31_Click);
            // 
            // label30
            // 
            this.label30.ImageList = this.imageList1;
            this.label30.Location = new System.Drawing.Point(674, 528);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(55, 28);
            this.label30.TabIndex = 75;
            this.label30.Click += new System.EventHandler(this.label30_Click);
            // 
            // label29
            // 
            this.label29.ImageList = this.imageList1;
            this.label29.Location = new System.Drawing.Point(613, 528);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(55, 28);
            this.label29.TabIndex = 74;
            this.label29.Click += new System.EventHandler(this.label29_Click);
            // 
            // label28
            // 
            this.label28.ImageList = this.imageList1;
            this.label28.Location = new System.Drawing.Point(552, 528);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(55, 28);
            this.label28.TabIndex = 73;
            this.label28.Click += new System.EventHandler(this.label28_Click);
            // 
            // label27
            // 
            this.label27.ImageList = this.imageList1;
            this.label27.Location = new System.Drawing.Point(491, 528);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(55, 28);
            this.label27.TabIndex = 72;
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // label26
            // 
            this.label26.ImageList = this.imageList1;
            this.label26.Location = new System.Drawing.Point(428, 528);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(55, 28);
            this.label26.TabIndex = 71;
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label25
            // 
            this.label25.ImageList = this.imageList1;
            this.label25.Location = new System.Drawing.Point(367, 528);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(55, 28);
            this.label25.TabIndex = 70;
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // label24
            // 
            this.label24.ImageList = this.imageList1;
            this.label24.Location = new System.Drawing.Point(367, 565);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(55, 28);
            this.label24.TabIndex = 69;
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label23
            // 
            this.label23.ImageList = this.imageList1;
            this.label23.Location = new System.Drawing.Point(428, 565);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(55, 28);
            this.label23.TabIndex = 68;
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label22
            // 
            this.label22.ImageList = this.imageList1;
            this.label22.Location = new System.Drawing.Point(489, 565);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(55, 28);
            this.label22.TabIndex = 67;
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label21
            // 
            this.label21.ImageList = this.imageList1;
            this.label21.Location = new System.Drawing.Point(550, 565);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(55, 28);
            this.label21.TabIndex = 66;
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label20
            // 
            this.label20.ImageList = this.imageList1;
            this.label20.Location = new System.Drawing.Point(613, 565);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(55, 28);
            this.label20.TabIndex = 65;
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label19
            // 
            this.label19.ImageList = this.imageList1;
            this.label19.Location = new System.Drawing.Point(674, 565);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(55, 28);
            this.label19.TabIndex = 64;
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label18
            // 
            this.label18.ImageList = this.imageList1;
            this.label18.Location = new System.Drawing.Point(735, 565);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(55, 28);
            this.label18.TabIndex = 63;
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label17
            // 
            this.label17.ImageList = this.imageList1;
            this.label17.Location = new System.Drawing.Point(796, 565);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(55, 28);
            this.label17.TabIndex = 62;
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label16
            // 
            this.label16.ImageList = this.imageList1;
            this.label16.Location = new System.Drawing.Point(796, 602);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(55, 28);
            this.label16.TabIndex = 61;
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label15
            // 
            this.label15.ImageList = this.imageList1;
            this.label15.Location = new System.Drawing.Point(735, 602);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(55, 28);
            this.label15.TabIndex = 60;
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label14
            // 
            this.label14.ImageList = this.imageList1;
            this.label14.Location = new System.Drawing.Point(674, 602);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(55, 28);
            this.label14.TabIndex = 59;
            this.label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // label13
            // 
            this.label13.ImageList = this.imageList1;
            this.label13.Location = new System.Drawing.Point(613, 602);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(55, 28);
            this.label13.TabIndex = 58;
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label12
            // 
            this.label12.ImageList = this.imageList1;
            this.label12.Location = new System.Drawing.Point(552, 602);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(55, 28);
            this.label12.TabIndex = 57;
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // label11
            // 
            this.label11.ImageList = this.imageList1;
            this.label11.Location = new System.Drawing.Point(489, 602);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(55, 28);
            this.label11.TabIndex = 56;
            this.label11.Click += new System.EventHandler(this.label11_Click);
            // 
            // label10
            // 
            this.label10.ImageList = this.imageList1;
            this.label10.Location = new System.Drawing.Point(428, 602);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 28);
            this.label10.TabIndex = 55;
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.ImageList = this.imageList1;
            this.label9.Location = new System.Drawing.Point(367, 602);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(55, 28);
            this.label9.TabIndex = 54;
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // label8
            // 
            this.label8.ImageList = this.imageList1;
            this.label8.Location = new System.Drawing.Point(367, 639);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 28);
            this.label8.TabIndex = 53;
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label7
            // 
            this.label7.ImageList = this.imageList1;
            this.label7.Location = new System.Drawing.Point(428, 639);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 28);
            this.label7.TabIndex = 52;
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label6
            // 
            this.label6.ImageList = this.imageList1;
            this.label6.Location = new System.Drawing.Point(489, 639);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 28);
            this.label6.TabIndex = 51;
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.ImageList = this.imageList1;
            this.label5.Location = new System.Drawing.Point(550, 639);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 28);
            this.label5.TabIndex = 50;
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.ImageList = this.imageList1;
            this.label4.Location = new System.Drawing.Point(613, 639);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(55, 28);
            this.label4.TabIndex = 49;
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label3
            // 
            this.label3.ImageList = this.imageList1;
            this.label3.Location = new System.Drawing.Point(674, 639);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 28);
            this.label3.TabIndex = 48;
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.ImageList = this.imageList1;
            this.label2.Location = new System.Drawing.Point(735, 639);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 28);
            this.label2.TabIndex = 47;
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label1
            // 
            this.label1.ImageList = this.imageList1;
            this.label1.Location = new System.Drawing.Point(796, 639);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 28);
            this.label1.TabIndex = 46;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(355, 376);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(505, 293);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 45;
            this.pictureBox1.TabStop = false;
            // 
            // txtExibetabuleiro
            // 
            this.txtExibetabuleiro.Location = new System.Drawing.Point(702, 45);
            this.txtExibetabuleiro.Multiline = true;
            this.txtExibetabuleiro.Name = "txtExibetabuleiro";
            this.txtExibetabuleiro.ReadOnly = true;
            this.txtExibetabuleiro.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtExibetabuleiro.Size = new System.Drawing.Size(121, 325);
            this.txtExibetabuleiro.TabIndex = 42;
            // 
            // txtPosicao
            // 
            this.txtPosicao.Location = new System.Drawing.Point(481, 46);
            this.txtPosicao.Name = "txtPosicao";
            this.txtPosicao.Size = new System.Drawing.Size(90, 20);
            this.txtPosicao.TabIndex = 41;
            this.txtPosicao.Tag = "15";
            // 
            // cboSimbolo
            // 
            this.cboSimbolo.FormattingEnabled = true;
            this.cboSimbolo.ItemHeight = 23;
            this.cboSimbolo.Items.AddRange(new object[] {
            "Esqueleto",
            "Chave",
            "Garrafa",
            "Pistola",
            "Tricórnio",
            "Faca"});
            this.cboSimbolo.Location = new System.Drawing.Point(481, 75);
            this.cboSimbolo.Name = "cboSimbolo";
            this.cboSimbolo.Size = new System.Drawing.Size(90, 29);
            this.cboSimbolo.TabIndex = 37;
            this.cboSimbolo.Tag = "16";
            this.cboSimbolo.UseSelectable = true;
            // 
            // cboPartida
            // 
            this.cboPartida.FormattingEnabled = true;
            this.cboPartida.ItemHeight = 23;
            this.cboPartida.Items.AddRange(new object[] {
            "Todas",
            "Aberta",
            "Jogando",
            "Encerrada"});
            this.cboPartida.Location = new System.Drawing.Point(103, 10);
            this.cboPartida.Name = "cboPartida";
            this.cboPartida.Size = new System.Drawing.Size(121, 29);
            this.cboPartida.TabIndex = 36;
            this.cboPartida.Tag = "2";
            this.cboPartida.UseSelectable = true;
            // 
            // lblSimbolo
            // 
            this.lblSimbolo.AutoSize = true;
            this.lblSimbolo.Location = new System.Drawing.Point(419, 80);
            this.lblSimbolo.Name = "lblSimbolo";
            this.lblSimbolo.Size = new System.Drawing.Size(61, 19);
            this.lblSimbolo.TabIndex = 34;
            this.lblSimbolo.Text = "Símbolo:";
            // 
            // lblPosicao
            // 
            this.lblPosicao.AutoSize = true;
            this.lblPosicao.Location = new System.Drawing.Point(419, 45);
            this.lblPosicao.Name = "lblPosicao";
            this.lblPosicao.Size = new System.Drawing.Size(56, 19);
            this.lblPosicao.TabIndex = 33;
            this.lblPosicao.Text = "Posição:";
            // 
            // lblCorJogador
            // 
            this.lblCorJogador.AutoSize = true;
            this.lblCorJogador.Location = new System.Drawing.Point(239, 365);
            this.lblCorJogador.Name = "lblCorJogador";
            this.lblCorJogador.Size = new System.Drawing.Size(35, 19);
            this.lblCorJogador.TabIndex = 32;
            this.lblCorJogador.Text = "Cor:";
            this.lblCorJogador.Theme = MetroFramework.MetroThemeStyle.Light;
            // 
            // lblSenhaJogador
            // 
            this.lblSenhaJogador.AutoSize = true;
            this.lblSenhaJogador.Location = new System.Drawing.Point(239, 317);
            this.lblSenhaJogador.Name = "lblSenhaJogador";
            this.lblSenhaJogador.Size = new System.Drawing.Size(121, 19);
            this.lblSenhaJogador.TabIndex = 31;
            this.lblSenhaJogador.Text = "Senha do Jogador:";
            // 
            // lblIdJogador
            // 
            this.lblIdJogador.AutoSize = true;
            this.lblIdJogador.Location = new System.Drawing.Point(239, 267);
            this.lblIdJogador.Name = "lblIdJogador";
            this.lblIdJogador.Size = new System.Drawing.Size(98, 19);
            this.lblIdJogador.TabIndex = 30;
            this.lblIdJogador.Text = "ID do Jogador:";
            // 
            // lblNomeJogador
            // 
            this.lblNomeJogador.AutoSize = true;
            this.lblNomeJogador.Location = new System.Drawing.Point(239, 170);
            this.lblNomeJogador.Name = "lblNomeJogador";
            this.lblNomeJogador.Size = new System.Drawing.Size(123, 19);
            this.lblNomeJogador.TabIndex = 29;
            this.lblNomeJogador.Text = "Nome do Jogador:";
            // 
            // lblIdPartida
            // 
            this.lblIdPartida.AutoSize = true;
            this.lblIdPartida.Location = new System.Drawing.Point(345, 15);
            this.lblIdPartida.Name = "lblIdPartida";
            this.lblIdPartida.Size = new System.Drawing.Size(24, 19);
            this.lblIdPartida.TabIndex = 28;
            this.lblIdPartida.Text = "ID:";
            // 
            // lblSenhaPartida
            // 
            this.lblSenhaPartida.AutoSize = true;
            this.lblSenhaPartida.Location = new System.Drawing.Point(22, 219);
            this.lblSenhaPartida.Name = "lblSenhaPartida";
            this.lblSenhaPartida.Size = new System.Drawing.Size(47, 19);
            this.lblSenhaPartida.TabIndex = 27;
            this.lblSenhaPartida.Text = "Senha:";
            // 
            // lblNomePartida
            // 
            this.lblNomePartida.AutoSize = true;
            this.lblNomePartida.Location = new System.Drawing.Point(22, 170);
            this.lblNomePartida.Name = "lblNomePartida";
            this.lblNomePartida.Size = new System.Drawing.Size(114, 19);
            this.lblNomePartida.TabIndex = 26;
            this.lblNomePartida.Text = "Nome da Partida:";
            // 
            // txtExibeVez
            // 
            this.txtExibeVez.Location = new System.Drawing.Point(577, 45);
            this.txtExibeVez.Multiline = true;
            this.txtExibeVez.Name = "txtExibeVez";
            this.txtExibeVez.ReadOnly = true;
            this.txtExibeVez.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtExibeVez.Size = new System.Drawing.Size(121, 325);
            this.txtExibeVez.TabIndex = 25;
            // 
            // txtExibeMao
            // 
            this.txtExibeMao.Location = new System.Drawing.Point(419, 311);
            this.txtExibeMao.Multiline = true;
            this.txtExibeMao.Name = "txtExibeMao";
            this.txtExibeMao.ReadOnly = true;
            this.txtExibeMao.Size = new System.Drawing.Size(152, 59);
            this.txtExibeMao.TabIndex = 24;
            // 
            // txtCorJogador
            // 
            this.txtCorJogador.Location = new System.Drawing.Point(239, 387);
            this.txtCorJogador.Name = "txtCorJogador";
            this.txtCorJogador.Size = new System.Drawing.Size(83, 20);
            this.txtCorJogador.TabIndex = 23;
            this.txtCorJogador.Tag = "13";
            // 
            // txtSenhaJogador
            // 
            this.txtSenhaJogador.Location = new System.Drawing.Point(239, 339);
            this.txtSenhaJogador.Name = "txtSenhaJogador";
            this.txtSenhaJogador.Size = new System.Drawing.Size(164, 20);
            this.txtSenhaJogador.TabIndex = 22;
            this.txtSenhaJogador.Tag = "12";
            // 
            // txtIdJogador
            // 
            this.txtIdJogador.Location = new System.Drawing.Point(239, 289);
            this.txtIdJogador.Name = "txtIdJogador";
            this.txtIdJogador.Size = new System.Drawing.Size(164, 20);
            this.txtIdJogador.TabIndex = 21;
            this.txtIdJogador.Tag = "11";
            // 
            // txtNomeJogador
            // 
            this.txtNomeJogador.Location = new System.Drawing.Point(239, 192);
            this.txtNomeJogador.Name = "txtNomeJogador";
            this.txtNomeJogador.Size = new System.Drawing.Size(164, 20);
            this.txtNomeJogador.TabIndex = 20;
            this.txtNomeJogador.Tag = "9";
            // 
            // txtExibeJogadores
            // 
            this.txtExibeJogadores.Location = new System.Drawing.Point(239, 45);
            this.txtExibeJogadores.Multiline = true;
            this.txtExibeJogadores.Name = "txtExibeJogadores";
            this.txtExibeJogadores.ReadOnly = true;
            this.txtExibeJogadores.Size = new System.Drawing.Size(164, 121);
            this.txtExibeJogadores.TabIndex = 19;
            // 
            // txtIdPartida
            // 
            this.txtIdPartida.Location = new System.Drawing.Point(375, 13);
            this.txtIdPartida.Name = "txtIdPartida";
            this.txtIdPartida.Size = new System.Drawing.Size(28, 20);
            this.txtIdPartida.TabIndex = 18;
            this.txtIdPartida.Tag = "8";
            // 
            // txtExibeHistorico
            // 
            this.txtExibeHistorico.Location = new System.Drawing.Point(22, 299);
            this.txtExibeHistorico.Multiline = true;
            this.txtExibeHistorico.Name = "txtExibeHistorico";
            this.txtExibeHistorico.ReadOnly = true;
            this.txtExibeHistorico.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtExibeHistorico.Size = new System.Drawing.Size(202, 108);
            this.txtExibeHistorico.TabIndex = 44;
            // 
            // txtSenhaPartida
            // 
            this.txtSenhaPartida.Location = new System.Drawing.Point(22, 241);
            this.txtSenhaPartida.Name = "txtSenhaPartida";
            this.txtSenhaPartida.Size = new System.Drawing.Size(75, 20);
            this.txtSenhaPartida.TabIndex = 16;
            this.txtSenhaPartida.Tag = "4";
            // 
            // txtNomePartida
            // 
            this.txtNomePartida.Location = new System.Drawing.Point(22, 193);
            this.txtNomePartida.Name = "txtNomePartida";
            this.txtNomePartida.Size = new System.Drawing.Size(202, 20);
            this.txtNomePartida.TabIndex = 15;
            this.txtNomePartida.Tag = "3";
            // 
            // txtExibePartida
            // 
            this.txtExibePartida.Location = new System.Drawing.Point(22, 45);
            this.txtExibePartida.Multiline = true;
            this.txtExibePartida.Name = "txtExibePartida";
            this.txtExibePartida.ReadOnly = true;
            this.txtExibePartida.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtExibePartida.Size = new System.Drawing.Size(202, 121);
            this.txtExibePartida.TabIndex = 14;
            // 
            // btnExibirTabuleiro
            // 
            this.btnExibirTabuleiro.Location = new System.Drawing.Point(704, 9);
            this.btnExibirTabuleiro.Name = "btnExibirTabuleiro";
            this.btnExibirTabuleiro.Size = new System.Drawing.Size(110, 30);
            this.btnExibirTabuleiro.TabIndex = 13;
            this.btnExibirTabuleiro.Tag = "22";
            this.btnExibirTabuleiro.Text = "Exibir Tabuleiro";
            this.btnExibirTabuleiro.UseSelectable = true;
            this.btnExibirTabuleiro.Click += new System.EventHandler(this.btnExibirTabuleiro_Click);
            // 
            // btnVerificarVez
            // 
            this.btnVerificarVez.Location = new System.Drawing.Point(577, 9);
            this.btnVerificarVez.Name = "btnVerificarVez";
            this.btnVerificarVez.Size = new System.Drawing.Size(121, 30);
            this.btnVerificarVez.TabIndex = 12;
            this.btnVerificarVez.Tag = "21";
            this.btnVerificarVez.Text = "Verificar Vez";
            this.btnVerificarVez.UseSelectable = true;
            this.btnVerificarVez.Click += new System.EventHandler(this.btnVerificarVez_Click);
            // 
            // btnExibirMao
            // 
            this.btnExibirMao.Location = new System.Drawing.Point(419, 263);
            this.btnExibirMao.Name = "btnExibirMao";
            this.btnExibirMao.Size = new System.Drawing.Size(152, 42);
            this.btnExibirMao.TabIndex = 11;
            this.btnExibirMao.Tag = "20";
            this.btnExibirMao.Text = "Exibir Mão";
            this.btnExibirMao.UseSelectable = true;
            this.btnExibirMao.Click += new System.EventHandler(this.btnExibirMao_Click);
            // 
            // btnPularJogada
            // 
            this.btnPularJogada.Location = new System.Drawing.Point(419, 215);
            this.btnPularJogada.Name = "btnPularJogada";
            this.btnPularJogada.Size = new System.Drawing.Size(152, 42);
            this.btnPularJogada.TabIndex = 10;
            this.btnPularJogada.Tag = "19";
            this.btnPularJogada.Text = "Pular Jogada";
            this.btnPularJogada.UseSelectable = true;
            this.btnPularJogada.Click += new System.EventHandler(this.btnPularJogada_Click);
            // 
            // btnJogarTras
            // 
            this.btnJogarTras.Location = new System.Drawing.Point(419, 167);
            this.btnJogarTras.Name = "btnJogarTras";
            this.btnJogarTras.Size = new System.Drawing.Size(152, 42);
            this.btnJogarTras.TabIndex = 9;
            this.btnJogarTras.Tag = "18";
            this.btnJogarTras.Text = "Jogar para Tras";
            this.btnJogarTras.UseSelectable = true;
            this.btnJogarTras.Click += new System.EventHandler(this.btnJogarTras_Click);
            // 
            // btnJogarFrente
            // 
            this.btnJogarFrente.Location = new System.Drawing.Point(419, 119);
            this.btnJogarFrente.Name = "btnJogarFrente";
            this.btnJogarFrente.Size = new System.Drawing.Size(152, 42);
            this.btnJogarFrente.TabIndex = 8;
            this.btnJogarFrente.Tag = "17";
            this.btnJogarFrente.Text = "Jogar para Frente";
            this.btnJogarFrente.UseSelectable = true;
            this.btnJogarFrente.Click += new System.EventHandler(this.btnJogarFrente_Click);
            // 
            // btnIniciarPartida
            // 
            this.btnIniciarPartida.Location = new System.Drawing.Point(419, 10);
            this.btnIniciarPartida.Name = "btnIniciarPartida";
            this.btnIniciarPartida.Size = new System.Drawing.Size(152, 29);
            this.btnIniciarPartida.TabIndex = 7;
            this.btnIniciarPartida.Tag = "14";
            this.btnIniciarPartida.Text = "Iniciar Partida";
            this.btnIniciarPartida.UseSelectable = true;
            this.btnIniciarPartida.Click += new System.EventHandler(this.btnIniciarPartida_Click);
            // 
            // btnEntrarPartida
            // 
            this.btnEntrarPartida.Location = new System.Drawing.Point(239, 241);
            this.btnEntrarPartida.Name = "btnEntrarPartida";
            this.btnEntrarPartida.Size = new System.Drawing.Size(164, 23);
            this.btnEntrarPartida.TabIndex = 6;
            this.btnEntrarPartida.Tag = "10";
            this.btnEntrarPartida.Text = "Entrar na Partida";
            this.btnEntrarPartida.UseSelectable = true;
            this.btnEntrarPartida.Click += new System.EventHandler(this.btnEntrarPartida_Click);
            // 
            // btnListarJogadores
            // 
            this.btnListarJogadores.Location = new System.Drawing.Point(239, 10);
            this.btnListarJogadores.Name = "btnListarJogadores";
            this.btnListarJogadores.Size = new System.Drawing.Size(100, 29);
            this.btnListarJogadores.TabIndex = 5;
            this.btnListarJogadores.Tag = "7";
            this.btnListarJogadores.Text = "Listar Jogadores";
            this.btnListarJogadores.UseSelectable = true;
            this.btnListarJogadores.Click += new System.EventHandler(this.btnListarJogadores_Click);
            // 
            // btnExibirHistorico
            // 
            this.btnExibirHistorico.Location = new System.Drawing.Point(22, 270);
            this.btnExibirHistorico.Name = "btnExibirHistorico";
            this.btnExibirHistorico.Size = new System.Drawing.Size(202, 23);
            this.btnExibirHistorico.TabIndex = 4;
            this.btnExibirHistorico.Tag = "6";
            this.btnExibirHistorico.Text = "Exibir Historico";
            this.btnExibirHistorico.UseSelectable = true;
            this.btnExibirHistorico.Click += new System.EventHandler(this.btnExibirHistorico_Click);
            // 
            // btnCriarPartida
            // 
            this.btnCriarPartida.Location = new System.Drawing.Point(103, 241);
            this.btnCriarPartida.Name = "btnCriarPartida";
            this.btnCriarPartida.Size = new System.Drawing.Size(121, 23);
            this.btnCriarPartida.TabIndex = 3;
            this.btnCriarPartida.Tag = "5";
            this.btnCriarPartida.Text = "Criar Partida";
            this.btnCriarPartida.UseSelectable = true;
            this.btnCriarPartida.Click += new System.EventHandler(this.btnCriarPartida_Click);
            // 
            // btmListarPartida
            // 
            this.btmListarPartida.Location = new System.Drawing.Point(20, 10);
            this.btmListarPartida.Name = "btmListarPartida";
            this.btmListarPartida.Size = new System.Drawing.Size(75, 29);
            this.btmListarPartida.TabIndex = 2;
            this.btmListarPartida.Tag = "1";
            this.btmListarPartida.Text = "Listar Partida";
            this.btmListarPartida.UseSelectable = true;
            this.btmListarPartida.Click += new System.EventHandler(this.btnListarPartida_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 676);
            this.Controls.Add(this.metroPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Interador";
            this.metroPanel1.ResumeLayout(false);
            this.metroPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private System.Windows.Forms.TextBox txtPosicao;
        private MetroFramework.Controls.MetroComboBox cboSimbolo;
        private MetroFramework.Controls.MetroComboBox cboPartida;
        private MetroFramework.Controls.MetroLabel lblSimbolo;
        private MetroFramework.Controls.MetroLabel lblPosicao;
        private MetroFramework.Controls.MetroLabel lblCorJogador;
        private MetroFramework.Controls.MetroLabel lblSenhaJogador;
        private MetroFramework.Controls.MetroLabel lblIdJogador;
        private MetroFramework.Controls.MetroLabel lblNomeJogador;
        private MetroFramework.Controls.MetroLabel lblIdPartida;
        private MetroFramework.Controls.MetroLabel lblSenhaPartida;
        private MetroFramework.Controls.MetroLabel lblNomePartida;
        private System.Windows.Forms.TextBox txtExibeVez;
        private System.Windows.Forms.TextBox txtExibeMao;
        private System.Windows.Forms.TextBox txtCorJogador;
        private System.Windows.Forms.TextBox txtSenhaJogador;
        private System.Windows.Forms.TextBox txtIdJogador;
        private System.Windows.Forms.TextBox txtNomeJogador;
        private System.Windows.Forms.TextBox txtExibeJogadores;
        private System.Windows.Forms.TextBox txtIdPartida;
        private System.Windows.Forms.TextBox txtExibeHistorico;
        private System.Windows.Forms.TextBox txtSenhaPartida;
        private System.Windows.Forms.TextBox txtNomePartida;
        private System.Windows.Forms.TextBox txtExibePartida;
        private MetroFramework.Controls.MetroButton btnExibirTabuleiro;
        private MetroFramework.Controls.MetroButton btnVerificarVez;
        private MetroFramework.Controls.MetroButton btnExibirMao;
        private MetroFramework.Controls.MetroButton btnPularJogada;
        private MetroFramework.Controls.MetroButton btnJogarTras;
        private MetroFramework.Controls.MetroButton btnJogarFrente;
        private MetroFramework.Controls.MetroButton btnIniciarPartida;
        private MetroFramework.Controls.MetroButton btnEntrarPartida;
        private MetroFramework.Controls.MetroButton btnListarJogadores;
        private MetroFramework.Controls.MetroButton btnExibirHistorico;
        private MetroFramework.Controls.MetroButton btnCriarPartida;
        private MetroFramework.Controls.MetroButton btmListarPartida;
        private System.Windows.Forms.TextBox txtExibetabuleiro;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList imageList1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
    }
}

